<div class="art-content-layout-wrapper layout-item-2">
													<div class="art-content-layout">
    													<div class="art-content-layout-row">
    														<div class="art-layout-cell layout-item-1" style="width: 100%;">
        														<h1>My Latest Works</h1>
    														</div>
    													</div>
													</div>
												</div>
												<div class="art-content-layout-br layout-item-0"></div>
                                                <div class="art-content-layout">
    												<div class="art-content-layout-row">
    													<div class="art-layout-cell" style="width: 100%;">                                                         
                                                        	
                                                            <h2>Happiness of Love and Romance</h2>
                											<p><img width="363" height="241" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/shutterstock_4717327.jpg" style="float:left;" /></p>
                                                            <?php the_post();?>
                                                            <h1> <?php the_title(); ?></h1>
                                                            <p><?php the_content(); ?></p>
                                                            <!-- 
                											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pharetra, tellus sit amet congue vulputate, nisi erat iaculis nibh, vitae feugiat sapien ante eget mauris. Cras elit nisl, rhoncus nec iaculis ultricies, feugiat eget.</p>
        													<p>Pellentesque ac felis tellus. Aenean sollicitudin imperdiet arcu, vitae dignissim est posuere id.Duis placerat justo eu nunc interdum ultricessit amet, posuere id.</p>
                											<p><a href="#" class="art-button">Read More</a></p> -->
    													</div> 
    												</div> 
												</div> 
												<div class="art-content-layout-br layout-item-0"></div>
                                                    <div class="art-content-layout">
                                                    	<div class="art-content-layout-row">
    														<div class="art-layout-cell" style="width: 100%;">
        														<h2>Graduation Opens Many Doors</h2>
               								 					<p><img width="360" height="248" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/shutterstock_20638912.jpg" style="float:left;" /></p>
                                                                <?php the_post();?>
                                                                <h1> <?php the_title(); ?></h1>
                                                                <p><?php the_content(); ?></p>
                                                                <!-- 
                												<p>Fusce ornare elit nisl, feugiat bibendum lorem. Vivamus pretium dictum sem vel laoreet. In fringilla pharetra purus, semper vulputate ligula cursus in. Donec at nunc nec dui laoreet porta eu eu ipsum. Sed eget lacus sit amet risus elementum dictum.</p>
                												<p>Aenean tellus mi, adipiscing sit amet laoreet eget, lobortis quis nisl. Quisque volutpat urna orci, id gravida nisi. Nullam posuere interdum est sit amet aliquam enim feugiat commodo.</p>
                												<p><a href="#" class="art-button">Read More</a></p> -->
    														</div>
    													</div>
													</div>
               	 								</div>
                								<div class="cleared"></div>
											</div>
											<div class="cleared"></div>
    									</div>
									</div>
                          			<div class="cleared"></div>
                        		</div>