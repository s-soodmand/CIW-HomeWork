		<div class="art-footer">
            <div class="art-footer-body">
                <div class="art-footer-center">
                    <div class="art-footer-wrapper">
                        <div class="art-footer-text">
                            <p>Copyright © 2011. All Rights Reserved.</p>
                            <p>vector graphics by <a href="#">www.bazaardesigns.com</a></p>
                            <p><br /></p>
                            <p><br /></p>
                            <div class="cleared"></div>
                            <p class="art-page-footer"><a href="#">Website Template</a> created with Artisteer.</p>
                        </div>
                    </div>
                </div>
                <div class="cleared"></div>
            </div>
    	</div>
    	<div class="cleared"></div>
	</div>
    <div class="darkbox"></div>
</body>
</html>