<?php 
	include('header.php'); 
	include('menu-top.php');
	include('content.php');
 	include('menu-right.php');
	include('sidebar.php');
	include('footer.php');
?>
									
								
    	
