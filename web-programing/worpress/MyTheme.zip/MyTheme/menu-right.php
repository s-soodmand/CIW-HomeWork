<div class="art-layout-cell art-sidebar1"> 
    <div class="art-box art-block">
        <div class="art-box-body art-block-body">
            <div class="art-box art-blockcontent">
                <div class="art-box-body art-blockcontent-body">
                    <br />
                    <p>
                        <a href="#"><img width="48" height="48" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/feed.png" /></a> 
                        <a href="#"><img width="48" height="48" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/facebook1.png" /></a> 
                        <a href="#"><img width="48" height="48" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/technorati1.png" /></a>
                        <br />
     					<br />
                        <a href="#"><img width="48" height="48" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/delicious1.png" /></a>   	
                        <a href="#"><img width="48" height="48" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/flickr1.png" /></a>   
                        <a href="#"><img width="48" height="48" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/picasa.png" /></a> 
                        <br />
                    </p>                
                    <div class="cleared"></div>
                </div>
            </div>
            <div class="cleared"></div>
        </div>
    </div>