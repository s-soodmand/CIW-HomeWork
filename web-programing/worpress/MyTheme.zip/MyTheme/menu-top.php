<div class="art-layout-wrapper">
                	<div class="art-content-layout">
                    	<div class="art-content-layout-row">
                       		<div class="art-layout-cell art-content">
								<div class="art-box art-post">
    								<div class="art-box-body art-post-body">
										<div class="art-post-inner art-article">
                               				<div class="art-postcontent">
                                                <div class="art-content-layout">
                                                    <div class="art-content-layout-row">
                                                        <div class="art-layout-cell layout-item-1" style="width: 100%;">
                                                            <h1>My Portfolio</h1>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="art-content-layout-br layout-item-0"></div>
                                                <div class="art-content-layout">
                                                    <div class="art-content-layout-row">
                                                        <div class="art-layout-cell" style="width: 20%;">
                                                            <p style="text-align: center; margin: 0px"><a href="#"><img width="102" height="102" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/paint.png" /></a></p>
                                                            <h5>Artistic</h5>
                                                        </div>
                                                        <div class="art-layout-cell" style="width: 20%;">
                                                            <p style="text-align: center;margin: 0px"><a href="#"><img width="102" height="102" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/people.png" /></a></p>
                                                            <h5>People</h5>
                                                        </div>
                                                        <div class="art-layout-cell" style="width: 20%;">
                                                            <p style="text-align: center;margin: 0px"><a href="#"><img width="102" height="102" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/home.png" /></a></p>
                                                            <h5>Country</h5>
                                                        </div>
                                                        <div class="art-layout-cell" style="width: 20%;">
                                                            <p style="text-align: center;margin:0px"><a href="#"><img width="102" height="102" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/building.png" /></a></p>
                                                            <h5>Industrial</h5>
                                                        </div>
                                                        <div class="art-layout-cell" style="width: 20%;">
                                                            <p style="text-align: center; margin: 0px"><a href="#"><img width="102" height="102" alt="" src="http://soudmand.ir/blog/wp-content/uploads/2012/09/school.png" /></a></p>
                                                            <h5>School</h5>
                                                        </div>
                                                    </div>
                                                </div>