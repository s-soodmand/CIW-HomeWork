                        <div class="art-box art-block">
                            <div class="art-box-body art-block-body">
                                <div class="art-box art-blockcontent">
                                    <div class="art-box-body art-blockcontent-body">
                                        <hr style="border: none; background-color: #808080; color: #dedede; height: 1px;" />
                                        <br />
                                        <p style="font-family:'Lucida Handwriting'; font-size:18px; color: #FCCB1D;">04/02/11</p>
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pharetra, tellus sit amet congue vulputate, nisi erat iaculis nibh.
                                            <br />
                                            <a href="#">Read more...</a>
                                        </p>
                                        <br />
                                        <br />
                                        <p style="font-family:'Lucida Handwriting'; font-size:18px; color: #FCCB1D;">03/21/11</p>
                                        <p>
                                            Cras elit nisl, rhoncus nec iaculis ultricies, feugiat eget sapien. Pellentesque ac felis tellus. Aenean sollicitudin imperdiet arcu.
                                            <br />
                                            <a href="#">Read more...</a>
                                        </p>
                                        <br />
                                        <br />
                                        <p style="font-family:'Lucida Handwriting'; font-size:18px; color: #FCCB1D;">03/15/11</p>
                                        <p>
                                            Duis placerat justo eu nunc interdum ultrices. Phasellus elit dolor, porttitor id consectetur sit amet, posuere id magna.
                                            <br />
                                            <a href="#">Read more...</a>
                                        </p>
                                        <br />
                                        <br />
                                        <p style="font-family:'Lucida Handwriting'; font-size:18px; color: #FCCB1D;">03/15/11</p>
                                        <p>
                                            Aenean tellus mi, adipiscing sit amet laoreet eget, lobortis quis nisl Quisque volutpat urna orci, id gravida nisi.<br />
                                            <a href="#">Read more...</a>
                                        </p>                
                                        <div class="cleared"></div>
                                    </div>
                                </div>
                                <div class="cleared"></div>
                            </div>
                        </div>
                        <div class="art-box art-block">
                            <div class="art-box-body art-block-body">
                                <div class="art-box art-blockcontent">
                                    <div class="art-box-body art-blockcontent-body">
                                        <hr style="border: none; background-color: #808080; color: #dedede; height: 1px;" />
                                        <p>	
                                            <br />
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pharetra, tellus sit amet congue vulputate, nisi erat iaculis nibh, vitae feugiat sapien ante eget mauris.
                                        </p>
                                        <p><br /></p>
                                        <p><a href="#">email@photica.com</a></p>                
                                        <div class="cleared"></div>
                                    </div>
                                </div>
                                <div class="cleared"></div>
                            </div>
                        </div>
                        <div class="cleared"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="cleared"></div>
        <div class="cleared"></div>
    </div>
</div>